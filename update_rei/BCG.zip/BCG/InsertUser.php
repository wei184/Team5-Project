<?php
	$servername = "localhost";
	$server_username = "root";
	$server_password = "root";
	$dbName = "BCG";

	$username = $_POST["usernamePost"];	//"orirei";
	$email = $_POST["emailPost"];	//"email";
	$password = $_POST["passwordPost"];	//"krks0829";
	$nickname = $_POST["nicknamePost"];
	$avatar = 1;
	// default value for deck and collection
	$deck = "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20";
	//$collection = "1,1,1,2,2,2,3,3,3,4,4,4,5,5,5,6,6,6,7,7,7,8,8,8,9,9,9,10,10,10,10,11,11,11,12,12,12,13,13,13,13,14,14,14,14,14,16,16,16,17,17,17,18,18,18,19,19,19,20,20,20";
	//$avatar = NULL;

	if($username != "" && $email != "" && $password != "") {
		// Make Connection
		$conn = new mysqli($servername, $server_username, $server_password, $dbName);
		// Check Connection
		if(!$conn) {
			die("Connection Failed. ". mysqli_connect_error());
		}
		//else echo("Connection Success!\n");
		$sql = "SELECT * FROM users WHERE username = '".$username."' ";
		$result = mysqli_query($conn, $sql);
		// Get the result and confirm login
		if(mysqli_num_rows($result) > 0) {
			echo "username already exists";
		} else {
			echo "yo";
			$sql = "INSERT INTO users(username, email, password, nickname, avatar, deck)
				VALUES ('".$username."','".$email."','".$password."','".$nickname."','".$avatar."','".$deck."')";
			$result = mysqli_query($conn, $sql);
			if(!result) echo "there was an error";
			else echo "Everything ok!";
		}
	}
?>