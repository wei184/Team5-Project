<?php
	$servername = "localhost";
	$username = "root";
	$password = "root";
	$dbName = "BCG";

	$user_username = $_POST["usernamePost"];
	$user_password = $_POST["passwordPost"];
	$avatar;
	$deck;

	// Make Connection
	$conn = new mysqli($servername, $username, $password, $dbName);
	// Check Connection
	if(!$conn) {
		die("Connection Failed. ". mysqli_connect_error());
	}

	$sql = "SELECT password FROM users WHERE username = '".$user_username."' ";
	$result = mysqli_query($conn, $sql);

	// Get the result and confirm login
	if(mysqli_num_rows($result) > 0) {
		//show data for each row
		while($row = mysqli_fetch_assoc($result)) {
			if($row['password'] == $user_password) {
				//echo "login success";
				// avatar
				$sql = "SELECT avatar FROM users WHERE username = '".$user_username."' ";
				$result = mysqli_query($conn, $sql);
				$row = mysqli_fetch_assoc($result);
				$avatar = $row['avatar'];
				// deck
				$sql = "SELECT deck FROM users WHERE username = '".$user_username."' ";
				$result = mysqli_query($conn, $sql);
				$row = mysqli_fetch_assoc($result);
				$deck = explode(",",$row['deck']);
				$dummy[0]["username"] = $user_username;
				$dummy[0]["avatar"] = $avatar;
				$dummy[0]["deck"] = $deck;
				$json = json_encode($dummy);
				header("Content-type: text/javascript; charset=utf-8");
				echo $json;
				exit();
			} else {
				echo "password incorrect";
			}
		}
	} else {
		echo "user not found";
	}
	//else echo("Failed\n");
?>