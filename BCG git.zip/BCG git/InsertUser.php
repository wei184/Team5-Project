<?php
	$servername = "";
	$server_username = "";
	$server_password = "";
	$dbName = "";

	$username = $_POST["usernamePost"];	//"orirei";
	$email = $_POST["emailPost"];	//"email";
	$password = $_POST["passwordPost"];	//"krks0829";
	$nickname = $_POST["nicknamePost"];
	//$avatar = NULL;

	if($username != "" && $email != "" && $password != "") {
		// Make Connection
		$conn = new mysqli($servername, $server_username, $server_password, $dbName);
		// Check Connection
		if(!$conn) {
			die("Connection Failed. ". mysqli_connect_error());
		}
		//else echo("Connection Success!\n");
		$sql = "SELECT * FROM users WHERE username = '".$username."' ";
		$result = mysqli_query($conn, $sql);
		// Get the result and confirm login
		if(mysqli_num_rows($result) > 0) {
			echo "username already exists";
		} else {
			$sql = "INSERT INTO users(username, email, password, nickname)
				VALUES ('".$username."','".$email."','".$password."','".$nickname."')";
			$result = mysqli_query($conn, $sql);
			if(!result) echo "there was an error";
			else echo "Everything ok!";
		}
	}
?>