<?php
	$servername = "";
	$username = "";
	$password = "";
	$dbName = "";

	$user_username = $_POST["usernamePost"];
	$nickname = $_POST["nicknamePost"];

	// Make Connection
	$conn = new mysqli($servername, $username, $password, $dbName);
	// Check Connection
	if(!$conn) {
		die("Connection Failed. ". mysqli_connect_error());
	}

	$sql = "SELECT * FROM users WHERE username = '".$user_username."' ";
	$result = mysqli_query($conn, $sql);

	// Get the result and confirm login
	if(mysqli_num_rows($result) > 0) {
				$sql = "UPDATE users SET nickname = '".$nickname."' WHERE username = '".$user_username."' ";
				$result = mysqli_query($conn, $sql);
				echo "nickname change success";
				break;
	} else {
		echo "user not found";
	}
	//else echo("Failed\n");
?>