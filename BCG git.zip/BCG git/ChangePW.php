<?php
	$servername = "";
	$username = "";
	$password = "";
	$dbName = "";

	$user_username = $_POST["usernamePost"];
	$currentPW = $_POST["currentPasswordPost"];
	$newPW = $_POST["newPasswordPost"];

	// Make Connection
	$conn = new mysqli($servername, $username, $password, $dbName);
	// Check Connection
	if(!$conn) {
		die("Connection Failed. ". mysqli_connect_error());
	}

	$sql = "SELECT * FROM users WHERE username = '".$user_username."' ";
	$result = mysqli_query($conn, $sql);

	// Get the result and confirm login
	if(mysqli_num_rows($result) > 0) {
		//show data for each row
		while($row = mysqli_fetch_assoc($result)) {
			if($row['password'] == $currentPW) {
				$sql = "UPDATE users SET password = '".$newPW."' WHERE username = '".$user_username."' ";
				$result = mysqli_query($conn, $sql);
				// sending a message
				$sql = "SELECT email FROM users WHERE username = '".$user_username."' ";
				$result = mysqli_query($conn, $sql);
				$row = mysqli_fetch_assoc($result);
				$to = $row['email'];
				$subject = "***IMPORTANT NOTIFICATION***";
				$message = "Password Changed. Your new Password: $newPW";
				$from = "orirei0829@hotmail.com";
				mail($to, $subject, $message, "From:" .$from);
				echo "password change success";
				break;
			} else {
				echo "current password incorrect";
			}
		}
	} else {
		echo "user not found";
	}
	//else echo("Failed\n");
?>