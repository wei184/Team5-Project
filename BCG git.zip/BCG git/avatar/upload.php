	<HTML>
	<HEAD>
	<meta charset=UTF-8">
	<title>画像登録＆アップロード</title>
</HEAD>
<BODY>
<FORM method="POST" enctype="multipart/form-data" action="upload.php">
	<P>画像登録＆アップロード</P>
	画像パス：<INPUT type="file" name="upfile" size="30"><BR>
	<INPUT type="submit" name="submit" value="送信">
</FORM>

<?php


if (count($_POST) > 0 && isset($_POST["submit"])){
	$upfile = $_FILES["upfile"]["tmp_name"];
	if ($upfile==""){
		print("ファイルのアップロードができませんでした。<BR>");
		exit;
	}

	// ファイル取得
	$imgdat = file_get_contents($upfile);
	$imgdat = mysql_real_escape_string($imgdat);

	// DB接続
	$dbLink = mysql_connect("","","");
	if (!$dbLink){
		echo "接続失敗";
	}
        // DB選択
	mysql_select_db("BCG",$dbLink);

	// データ追加
	$sql = "INSERT INTO images(img) VALUES ('$imgdat')";

	$result = mysql_query($sql, $dbLink);
	if (!$result){
		print("SQLの実行に失敗しました<BR>");
		print(mysql_errno().": ".mysql_error()."<BR>");
		exit;
	}

	print("登録が終了しました<BR>");
	}
	?>
	</BODY>
	</HTML>