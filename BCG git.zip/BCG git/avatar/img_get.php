<?php
	// DB接続
	$dbLink = mysql_connect("","","");
		if (!$dbLink){
			echo "接続失敗";
		}
	//DB選択
		mysql_select_db("BCG",$dbLink);

	// 画像データ取得
	$sql = "SELECT img FROM images WHERE ID = '".$_GET['id']."' ");
	$result = mysql_query($sql, $dbLink);
	$row = mysql_fetch_row($result);

	// 画像ヘッダとしてjpegを指定（取得データがjpegの場合）
	header("Content-Type: image/png");

	// バイナリデータを直接表示
	echo $row[0];
?>